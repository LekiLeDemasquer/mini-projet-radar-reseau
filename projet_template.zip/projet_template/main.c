#include "stm32f7xx.h"                  // Device header

extern void configuration_overclock(void);
extern int Init_GUIThread (void);
extern void Init_Ethernet (void);

#ifdef _RTE_
#include "RTE_Components.h"             // Component selection
#endif
#ifdef RTE_CMSIS_RTOS2                  // when RTE component CMSIS RTOS2 is used
#include "cmsis_os2.h"                  // ::CMSIS:RTOS2
#endif

/*----------------------------------------------------------------------------
 *      T�che de test (vide) : � compl�ter par les �tudiants
 *---------------------------------------------------------------------------*/
osThreadId_t tid_Test;
void servo_set_angle(int deg);

static void Thread_Test (void *argument)
{
    (void)argument;

    while (1)
    {
        servo_set_angle(0);
        osDelay(1000);

        servo_set_angle(90);
        osDelay(1000);

        servo_set_angle(180);
        osDelay(1000);
    }
}

static int Init_TestThread (void)
{
  tid_Test = osThreadNew(Thread_Test, NULL, NULL);
  if (tid_Test == NULL) {
    return -1;
  }
  return 0;
}

void servo_set_angle(int deg)
{
    if (deg < 0)
        deg = 0;

    if (deg > 180)
        deg = 180;

    TIM13->CCR1 = 1000 + (deg * 1000) / 180;
}

int lire_potentiometre(void)
{
    ADC3->CR2 |= (1<<30);       // Demarrer conversion

    while (!(ADC3->SR & (1<<1))); // Attendre fin conversion

    return ADC3->DR;           // Recuperer valeur
}

int main(void)
{
  configuration_overclock(); //pour pouvoir utiliser l'�cran LCD

	/**********************************
	D�but Initialisation p�riph�rique
	**********************************/
	//Entrainement Led
	RCC -> AHB1ENR |=(1<<8);
	GPIOI->MODER|= (1<<2); 
	
	//Entrainement slider
	RCC->APB1ENR |= (1<<29);//activation DAC
	RCC->AHB1ENR |= (1<<0); //activation  GPIO A
	GPIOA->MODER |= (3<<8); //PA4 analogique
	DAC->CR |= (1<<0);//active sortie PA4
	
	//Entrainement rotary
	//Activation des horloges
	RCC->AHB1ENR |= (1<<5);  //Activation GPIOF
	RCC->APB2ENR |= (1<<17); //Activation TIM10
	//Configuration PF6 en fonction alternative AF3
	GPIOF->MODER |= (2<<12);
	GPIOF->AFR[0] |= (3<<24);
	//Configuration du PWM
	TIM10->CCMR1 |= (6<<4);  //Mode PWM 1
	TIM10->CCER |= (1<<0);   //Activation sortie CH1
	//Configuration du timer
	TIM10->PSC = 7;
	TIM10->ARR = 39999;
	TIM10->CCR1 = 4000;     //Rapport cyclique initial 10%
	//Demarrage timer
	TIM10->CR1 |= (1<<0);
	
	// Configuration servomoteur sur PF8 - TIM13
	 RCC->AHB1ENR |= (1<<5);  // Activation GPIOF
	 RCC->APB1ENR |= (1<<7);  // Activation TIM13
	 GPIOF->MODER &= ~(3<<16);
	 GPIOF->MODER |= (2<<16); // PF8 fonction alternative
	 GPIOF->AFR[1] &= ~(15<<0);
	 GPIOF->AFR[1] |= (9<<0); // AF9 : TIM13_CH1
	 TIM13->CCMR1 |= (6<<4); // Mode PWM 1
	 TIM13->CCER |= (1<<0);  // Activation CH1
	 TIM13->PSC = 107;
	 TIM13->ARR = 19999;
	 TIM13->CCR1 = 1500;     // Position initiale 90�
	 TIM13->CR1 |= (1<<0);  // Demarrage TIM13
	
	 
	 //Entrainement potentiometre

 RCC->AHB1ENR |= (1<<5);   // Activation GPIOF
 RCC->APB2ENR |= (1<<10);  // Activation ADC3

 GPIOF->MODER |= (3<<20);  // PF10 en analogique

 ADC3->SQR1 &= ~(15<<20); // Une seule conversion
 ADC3->SQR3 &= ~(31<<0);
 ADC3->SQR3 |= (8<<0);    // Canal 8

 ADC3->CR2 |= (1<<0);     // Activation ADC3

	
	
	
	/**********************************
	Fin Initialisation p�riph�rique
	**********************************/

	/**********************************
	Utilisation RTOS (Keil RTX5)
	**********************************/
	#ifdef RTE_CMSIS_RTOS2
	  /* Initialize CMSIS-RTOS2 */
	  osKernelInitialize ();

	  /* Create thread functions that start executing */
		Init_Ethernet();
		Init_GUIThread();
		Init_TestThread();   // t�che de test (boucle avec osDelay)

	  /* Start thread execution */
	  osKernelStart();
	#endif

  /* Infinite loop  (ne s'ex�cute pas avec le RTOS!!!)*/
  while (1)
  {
  }
}